# Changelog

### 2.0.0 - 2017-09-27

* Rewrite for the version 2 API.

### 1.0.2 - 2016-05-04

* Update for libsodium-php 1.0.6
* Added `\Sodium\crypto_pwhash*`

### 1.0.1 - 2015-09-08 - New Recipe, Typo Fixes

* Added an encrypted hash recipe
* Jacob Dreesen (@jdreesen) fixed several typos

### 1.0.0 - 2015-09-04 - First Edition

First edition. API coverage is complete at this state.

### 0.0.2 - 2015-08-29 - Rough Drafts

We've published rough drafts for Chapters 1, 3, 4, and 5.

Chapter 6 will come later tonight, possibly with 7 and 8 soon after. Chapter 9 
will be a concerted effort, Chapter 10 will be fun.

Chapter 2 should be the last one we write.

### 0.0.1 - 2015-08-28 - Initial skeleton

Set up the layout for the documentation